package com.yedam.erp.stocks;

import java.util.List;

public interface StockInOutService {

	public List<StockInOutViewVO> getStockInOutList(StockInOutVO vo);
	
	public List<StockInOutViewVO> getItemInOutList(StockInOutVO vo);
	
}
