package com.yedam.erp.stocks;

import java.util.List;

public interface StockOnhandService {
	
	public List<StockOnhandViewVO> getStockOnhandList(StockOnhandVO vo);
}
