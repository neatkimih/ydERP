package com.yedam.erp.stocks;

import java.util.List;

public interface PurchaseRequestService {

	public List<PurchaseRequestVO> getPurchaseReqeustList(PurchaseRequestVO vo);

}
