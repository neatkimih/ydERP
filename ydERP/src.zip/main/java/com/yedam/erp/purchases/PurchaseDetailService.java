package com.yedam.erp.purchases;

import java.util.List;

public interface PurchaseDetailService {

	public List<PurchaseDetailVO> getPurchaseDetailList(PurchasesVO vo);

}
